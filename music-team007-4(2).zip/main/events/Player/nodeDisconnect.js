module.exports = async (client, node, reason) => {

	console.log(`LAVALINK ${node.options.identifier} disconnect.`)

}