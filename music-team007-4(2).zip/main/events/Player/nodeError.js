module.exports = async (client, node, error) => {
	console.log(`LAVALINK ${node.options.identifier} encountered an error: ${error.message}.`)

}