module.exports = async (client, node) => {

  console.log(`LAVALINK ${node.options.identifier} successfully created.`)

}