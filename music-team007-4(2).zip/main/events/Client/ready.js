

module.exports = async (client) => {
    client.manager.init(client.user.id);
   

}