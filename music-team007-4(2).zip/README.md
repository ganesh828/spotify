# Advance Music Bot With Many Features 

 This Is Advance Music Bot With Many Features Updates Come Everyweek...!!!!!
 
```json
{
    "token": "Your Token",  
  "mongourl": "mongo url",
  "embedColor": "#FFFF00",
  "prefix": "prefix",
  "owners": "ur id",
     "nodes": [
    {
      "host": "",
      "port": ,
      "password": "",
      "retryDelay": ,
      "secure": 
  
  
    }
  ]
  } 
  ```

  Fill These And Go To Console And Type,
  
  ```bash
  npm install
  node index.js
  ```
